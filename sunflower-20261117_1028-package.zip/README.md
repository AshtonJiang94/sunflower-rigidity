# 葵花完整论文与改进方法：修订完整包

本包包含研究主稿《葵花检测器的MDS分类、分层优化与包络计数的极限》、配套完整证明重构稿，以及主要贡献说明。三项均有中英文Word和LaTeX。所有正式Word公式为原生可编辑OMML，不是公式图片。

署名：姜志成 / JIANG ZHICHENG；无机构、邮箱或新增作者。本次仅向作者交付文件，不公开、不投稿、不上传arXiv。

## 目录

- manuscripts/：中英文研究主稿与完整证明重构稿，Word和LaTeX。
- editorial/：中英文主要贡献说明、2026年11月17日修订与文献核查记录；history/保留明确注明日期的上一阶段记录。
- sources/：六份语义LaTeX源稿。
- tex_source/：两篇英文论文的独立ASCII源目录，main.tex无需依赖其他论文目录。
- document_tools/：Word公式转换及重建工具，已新增外部引用误用内部标签的硬检查。
- code/：完整数学复核与探索代码；探索程序不能替代一般证明。
- logs/、run_results.json：本次七项完整数学验证结果。
- qa/：本次生成、外部引用、展示公式、Word结构及包完整性QA。
- manifest_sha256.json：全部包成员的SHA-256校验清单。

## 修订范围

修正Bucić–He–Lee外部引用为Lemma 6、Lemma 3、Proposition 8；Karasev–Petrov系数提取引用为Theorem 4。两种语言、Word、LaTeX与ASCII源稿同步。引言补明Ahmadi–Norouzi三瓣专门界，修正少量正文措辞，更新主要贡献说明和审核记录。保留原有主定理、证明和展示公式，不将引用修复包装成新数学结果。

研究主稿保留原作基础归属；完整证明稿属于自包含重构。MDS分类、偶数瓣刚性和完整包络计数结果的优先权仍待独立核查。“最优”仅针对稿件规定的方法类。

## 数学复核

在普通Python 3环境安装requirements.txt中的依赖，禁止Python -O。运行：

python verify_all.py --mode full

七项入口在本次修订中均通过。quick模式省略两个区间证书。NumPy和SciPy只为区间程序提出候选，可信界由整数比较或向外舍入的Arb算术支持。有限回归不是全参数证明、专家审议或Lean形式化。

## Word重建

python document_tools/rebuild_word.py

工具从sources/的六份语义源稿生成Word及相应LaTeX副本到rebuilt/。外部文献定位必须写外部原文的固定编号，不得使用本稿内部ref或eqref标签；违反即停止构建。

## 编译与公开提交

本包尚未实际编译LaTeX，未提供PDF，不宣称通过编译。英文论文使用pdfLaTeX及amsmath、amssymb、amsthm、geometry、hyperref；中文论文使用XeLaTeX、ctex与可用中文字体。贡献说明使用其各自源文件声明的包。正式提交前完成实际编译并检查编译日志、未定义引用和公式。

未完成独立数学审阅或最终优先权认证。实质AI参与在正文披露，AI不列作者；数学主张与公开提交由人类作者审核决定。请使用本包，不使用11月12日旧包作为发布源。

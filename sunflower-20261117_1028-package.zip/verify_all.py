from pathlib import Path
import argparse,subprocess,sys,json,time,os
ROOT=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Do not run with Python -O')
ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['quick','full'],default='full');args=ap.parse_args()
files=['code/quantitative/four_petal_certificate_v2.py','code/quantitative/verify_rigidity_v2.py','code/quantitative/verify_proof_chain.py','code/quantitative/verify_standalone_constants.py','code/structural/verify_new_structure.py']
if args.mode=='full':files+=['code/quantitative/certify_four_optimum_v2.py','code/quantitative/certify_gamma_v2.py']
records=[];(ROOT/'logs').mkdir(exist_ok=True)
for f in files:
 t=time.monotonic();path=ROOT/f;env=dict(os.environ,OPENBLAS_NUM_THREADS='1',PYTHONOPTIMIZE='0');p=subprocess.run([sys.executable,str(path)],cwd=path.parent,env=env,capture_output=True,text=True);(ROOT/'logs'/(path.stem+'.log')).write_text(p.stdout+'\nSTDERR\n'+p.stderr);r={'script':f,'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-t,2)};records.append(r);print(r,flush=True)
 if p.returncode:raise RuntimeError(f+' failed')
(ROOT/'run_results.json').write_text(json.dumps({'scripts':records,'all_passed':True},indent=2))

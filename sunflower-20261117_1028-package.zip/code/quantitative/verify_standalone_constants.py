"""Exact regression checks for the problem-first proof's explicit constants.
These finite tests are not a substitute for its all-parameter proofs.
Uses only the Python standard library.
"""
from fractions import Fraction as Q
from math import comb
from pathlib import Path
import json

def check():
    counts={'elementary_binomial_cases':0,'vector_base_cases':0,'set_rational_cases':0}
    for m in range(2,102):
        r=m-1
        binomial=sum(Q(comb(r,j),r**j) for j in range(r+1))
        assert binomial==(Q(m,m-1))**(m-1)<3
        assert 3*m*m<4*(m+1)**2
        counts['elementary_binomial_cases']+=1
        for D in [3*m*m+1,4*m*m,7*m*m+3]:
            t=Q(D-m,m*(m-1));assert t>1
            # B^m=(D-m+mt)^m/t, without irrational arithmetic.
            base_m=(D-m+m*t)**m/t
            closed=m*m*(Q(m,m-1))**(m-1)*(D-m)**(m-1)
            assert base_m==closed<3*m*m*D**(m-1)
            counts['vector_base_cases']+=1
        lam=Q(1,3*m*(4*m*m-1))
        assert lam/(1+lam)==Q(1,12*m**3-3*m+1)>=Q(1,12*m**3)
        assert Q(1,3*m)<=Q(1,6) and Q(6,5)<2
        assert 4*m*m*Q(5,6)>1
        counts['set_rational_cases']+=1
    return dict(counts,passed=True,arithmetic='exact integers and rational numbers',evidence='finite regression checks only')

if __name__=='__main__':
    result=check();print(json.dumps(result,indent=2))
    Path(__file__).with_name('standalone_constant_checks.json').write_text(json.dumps(result,indent=2))

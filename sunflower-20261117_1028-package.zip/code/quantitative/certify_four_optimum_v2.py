"""Certifies global integer D optimality for m=3 within the profile/block model.
Real optimization suggested endpoints only. All root bracket signs are Arb-verified.
Analytic tail uses lambda(D)<= (2/3)log(4D/9)/(D-1), decreasing for D>=300.
"""
from pathlib import Path
from flint import arb,ctx
from scipy.optimize import brentq
from scipy.special import xlogy
from math import log

def kl(a,p):return float(xlogy(a,a/p)+xlogy(1-a,(1-a)/(1-p)))
def optimum(m,D):
 ps=[i/D for i in range(1,m+1)]
 def inv(r,p):return brentq(lambda a:kl(a,p)-r,p,1,xtol=1e-13)
 r=brentq(lambda r:sum(inv(r,p) for p in ps)-1,0,log(D/m)*(1-1e-12),xtol=1e-12)
 return r,[inv(r,p) for p in ps]
import json,time
ctx.prec=100;DEN=2**42;START=time.time()
def KL(a,p):return a*(a/p).log()+(1-a)*((1-a)/(1-p)).log()
def inverse_bracket(r,i,D):
 p=arb(i)/D;rf=float(r);s=brentq(lambda a:kl(a,i/D)-rf,i/D,1,xtol=1e-14)
 mid=int(round(s*DEN));step=2
 for _ in range(25):
  lo=arb(mid-step)/DEN;hi=arb(mid+step)/DEN
  if lo>p and hi<1 and KL(lo,p)<r and KL(hi,p)>r:return lo,hi
  step*=2
 raise AssertionError(('inverse',D,i,str(r)))
def rate_bracket(D):
 rr,_=optimum(3,D);mid=int(round(rr*DEN));step=16
 for _ in range(25):
  rL=arb(mid-step)/DEN;rU=arb(mid+step)/DEN
  LL=[];UU=[]
  for i in range(1,4):
   _,hi=inverse_bracket(rL,i,D);lo,_=inverse_bracket(rU,i,D)
   LL.append(hi);UU.append(lo)
  if sum(LL,arb(0))<1 and sum(UU,arb(0))>1:return rL,rU
  step*=2
 raise AssertionError(('rate',D))
if __name__=='__main__':
 roots={};data=[]
 for D in range(7,300):
  lo,hi=rate_bracket(D);roots[D]=(lo/(D-1),hi/(D-1))
  data.append({'D':D,'rate_lower':str(lo),'rate_upper':str(hi),'lambda_lower':str(roots[D][0]),'lambda_upper':str(roots[D][1])})
 bestlo=roots[25][0]
 assert all(bestlo>hi for D,(lo,hi) in roots.items() if D!=25)
 tail=arb(2)/3*(arb(400)/3).log()/299
 assert bestlo>tail
 cert={'m':3,'unique_optimal_integer_D':25,'finite_range':[7,299],'all_finite_competitors_verified':True,'tail_D_at_least':300,'tail_upper_ball':str(tail),'best_lambda_lower':str(bestlo),'best_lambda_upper':str(roots[25][1]),'root_brackets':data,'passed':True,'elapsed_seconds':time.time()-START}
 print({k:v for k,v in cert.items() if k!='root_brackets'})
 Path(__file__).with_name('four_optimum_certificate_v2.json').write_text(json.dumps(cert,indent=2))

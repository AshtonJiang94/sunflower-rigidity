"""Exact nested barycentric contractions; checks, not replacements for proof."""
from fractions import Fraction as Q
from itertools import permutations,product
from pathlib import Path
import json
from math import prod

def qvalue(a):
 if len(set(a))==1:return Q(1)
 if len(set(a))<len(a):return Q(0)
 return Q((-1)**(len(a)-2))*prod((Q(a[r]-a[s],a[0]-a[s]) for r in range(1,len(a)) for s in range(1,r)),start=Q(1))

def weights(S):return {x:1/__import__('math').prod((Q(x-y) for y in S if y!=x),start=Q(1)) for x in S}
def force(a):
 W=[weights(a[:i+1]) for i in range(1,len(a))]
 return -__import__('math').prod((w[a[0]]/w[a[i]] for i,w in enumerate(W,1)),start=Q(1))
reports=[];check=0
for nodes,k in [([0,1,2,3],3),([-3,0,2,7,11],4),([0,2,5,9,14],5)]:
 for a in permutations(nodes,k):
  assert force(a)==qvalue(a);check+=1
  W=[weights(a[:i+1]) for i in range(1,k)]
  for i,w in enumerate(W,1):
   for e in range(i):assert sum((v*Q(x)**e for x,v in w.items()),Q(0))==0
  total=Q(0)
  for xs in product(*[list(w) for w in W]):
   total+=qvalue((a[0],)+xs)*__import__('math').prod((W[i][x] for i,x in enumerate(xs)),start=Q(1))
  assert total==0
 reports.append({'nodes':nodes,'k':k,'all_rainbow_tuples_checked':__import__('math').factorial(len(nodes))//__import__('math').factorial(len(nodes)-k),'passed':True})
# For every deficient sorted profile, the prefix grid contains no rainbow tuple.
# Consequently its weighted contraction of a normalized valid detector is the
# nonzero monochrome contribution; it cannot lie in that low-space sum.
deficient=[]
for m in range(2,6):
 for ds in product(range(m+1),repeat=m):
  if tuple(sorted(ds))!=ds or all(d>=i for i,d in enumerate(ds,1)):continue
  W=[weights(tuple(range(d+1))) for d in ds]
  assert all(len(set((0,)+xs))<m+1 for xs in product(*[list(w) for w in W]))
  diagonal=__import__('math').prod((w[0] for w in W),start=Q(1));assert diagonal!=0
  deficient.append({'m':m,'dimensions':ds,'nonzero_monochrome_contraction':str(diagonal)})
out={'rigidity_checks':reports,'rainbow_checks':check,'deficient_profiles_checked':len(deficient),'all_checks_exact_rational':True,'passed':True}
print(json.dumps(out,indent=2))
Path(__file__).with_name('rigidity_verification_v2.json').write_text(json.dumps(out,indent=2))

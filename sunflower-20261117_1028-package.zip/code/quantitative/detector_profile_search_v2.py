from itertools import product,permutations
from pathlib import Path
import numpy as np,json,time
START=time.time()
def interp(D,P):
 A=np.empty((D,D),dtype=np.int64)
 for d in range(D):
  co=[1];den=1
  for e in range(D):
   if d==e:continue
   cc=[0]*(len(co)+1)
   for j,c in enumerate(co):cc[j]=(cc[j]-e*c)%P;cc[j+1]=(cc[j+1]+c)%P
   co=cc;den=den*(d-e)%P
  A[:,d]=np.array(co)*pow(den,-1,P)%P
 return A

def eliminate(M,P):
 M=M.copy();nr,nc=M.shape;rank=0;piv=[]
 for col in range(nc-1):
  ids=np.flatnonzero(M[rank:,col]);
  if not len(ids):continue
  t=rank+int(ids[0]);M[[rank,t]]=M[[t,rank]]
  M[rank]=M[rank]*pow(int(M[rank,col]),-1,P)%P
  inds=np.flatnonzero(M[:,col]);inds=inds[inds!=rank]
  M[inds]=(M[inds]-M[inds,col,None]*M[rank,None,:])%P
  piv.append(col);rank+=1
  if rank==nr:break
 inconsistent=bool(np.any((M[:, :-1]==0).all(axis=1)&(M[:,-1]!=0)))
 return rank,inconsistent

def run(D,ds,P=1000003):
 k=len(ds);A=interp(D,P);rain=np.array(list(permutations(range(D),k)))
 high=product(*[range(d,D) for d in ds]);rows=[]
 for es in high:
  rr=np.ones(len(rain),dtype=np.int64);mm=np.ones(D,dtype=np.int64)
  for i,e in enumerate(es):rr=rr*A[e,rain[:,i]]%P;mm=mm*A[e,:]%P
  rows.append(np.r_[rr,-sum(mm)%P])
 M=np.array(rows);rank,bad=eliminate(M,P)
 return {'D':D,'dimensions':ds,'prime':P,'rainbow_unknowns':len(rain),'constraints':len(rows),'rank_mod_p':rank,'consistent_mod_p':not bad,'affine_dimension_mod_p':len(rain)-rank if not bad else None,'seconds':time.time()-START,'interpretation':'inconsistency over this finite field is not a characteristic-zero impossibility certificate'}
if __name__=='__main__':
 out=[]
 for D in [4,5,6]:
  for ds in [(0,1,2,3),(0,1,2,2),(0,1,1,3),(1,1,1,2),(1,1,2,2),(1,1,1,3)]:
   z=run(D,ds);out.append(z);print(z,flush=True)
 Path(__file__).with_name('detector_profile_search_v2.json').write_text(json.dumps(out,indent=2))

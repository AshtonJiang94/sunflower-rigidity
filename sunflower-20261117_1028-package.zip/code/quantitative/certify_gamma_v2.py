"""Arb ball arithmetic certificate, no floating-point number is trusted as a bound.
Float/SciPy only suggests enclosures, every enclosure is verified by Arb signs.
Darboux sums for c' and concavity trapezoid/midpoint bounds for c.
"""
from pathlib import Path
import time,json
import numpy as np
from scipy.special import lambertw
from flint import arb,ctx
ctx.prec=100
START=time.time();M=2**18;DEN=2**34

def enclosure(suggest,x,u):
 mid=int(round(float(suggest)*DEN));step=2
 for _ in range(24):
  lo=arb(mid-step)/DEN;hi=arb(mid+step)/DEN
  jl=lo*(lo/x).log()-lo+x;jh=hi*(hi/x).log()-hi+x
  if lo>x and jl<u and jh>u:
   cp_lo=1/(hi/x).log();cp_hi=1/(lo/x).log()
   return lo,hi,cp_lo,cp_hi
  step*=2
 raise AssertionError(('enclosure failure',x,u,suggest))

def sums(num,den):
 u=arb(num)/den
 # Use vectorized inverse solely to propose pointwise dyadic enclosures.
 X=np.arange(1,2*M+1,dtype=float)/(2*M)
 Z=(num/den)/X-1
 B=X*Z/lambertw(Z/np.e).real
 trapL=arb(0);trapU=arb(0);midU=arb(0);derL=arb(0);derU=arb(0)
 end=None
 for idx,sug in enumerate(B,1):
  x=arb(idx)/(2*M);lo,hi,cplo,cphi=enclosure(sug,x,u)
  if idx%2:
   midU+=hi
  elif idx<2*M:
   trapL+=lo;trapU+=hi;derL+=cplo;derU+=cphi
  else:end=(lo,hi,cplo,cphi)
 lo,hi,cplo,cphi=end
 cL=(trapL+lo/2)/M;cU=midU/M
 cpL=derL/M;cpU=(derU+cphi)/M
 # c'(0)=0 in continuous extension. Include only right endpoint in upper sum.
 LL=u*cpL/cU;LU=u*cpU/cL
 return {'u_num':num,'u_den':den,'M':M,'c_lower':str(cL),'c_upper':str(cU),'L_lower':str(LL),'L_upper':str(LU)},(LL,LU,end)

if __name__=='__main__':
 out=[];roots=[]
 for num,den in [(20200,10000),(4041,2000)]:
  z,data=sums(num,den);out.append(z);roots.append(data);print(z,flush=True)
 assert roots[0][1]<arb(1)/2
 assert roots[1][0]>arb(1)/2
 # At the critical point c=2y/3; h(y)=u.
 # g(y)=9h(y)/(4y^2) is increasing over the certified y interval.
 ylo=roots[0][2][0];yhi=roots[1][2][1]
 def g(y):return 9*(y*y.log()-y+1)/(4*y*y)
 # derivative sign: y log y - 2h(y)>0; use interval bound.
 assert ylo>arb(3) and yhi<arb(4)
 # y(2-log y)-2 positive on [3,4], its minimum at 4 is positive.
 assert arb(4)*(2-arb(4).log())-2>0
 glo=g(ylo);ghi=g(yhi)
 assert glo>arb(34938)/100000
 assert ghi<arb(34940)/100000
 cert={'integrals':out,'u_bracket':['101/50','4041/2000'],'gamma_lower_ball':str(glo),'gamma_upper_ball':str(ghi),'certified_gamma_interval':['0.34938','0.34940'],'pointwise_enclosures_verified':4*M,'arb_precision_bits':ctx.prec,'elapsed_seconds':time.time()-START,'passed':True}
 print(json.dumps(cert,indent=2),flush=True)
 Path(__file__).with_name('gamma_certificate_v2.json').write_text(json.dumps(cert,indent=2))

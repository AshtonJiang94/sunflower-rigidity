"""Exact finite regression checks for the complete proof chain.
Standard library only. Finite checks detect errors; they do not prove the
all-parameter theorems. The rational certificates are in a separate script.
"""
from fractions import Fraction as Q
from itertools import product, permutations, combinations
from math import comb, prod
from pathlib import Path
import json

def detector(a):
    if len(set(a)) == 1:
        return Q(1)
    if len(set(a)) < len(a):
        return Q(0)
    m = len(a) - 1
    return Q((-1)**(m-1)) * prod(
        (Q(a[r]-a[s], a[0]-a[s])
         for r in range(1, m+1) for s in range(1, r)), start=Q(1))

def polynomial(prefix):
    if len(set(prefix)) < len(prefix):
        return [Q(0)] * len(prefix)
    coeff = [Q(1)]
    for a in prefix[1:]:
        new = [Q(0)] * (len(coeff)+1)
        for j,c in enumerate(coeff):
            new[j] -= a*c
            new[j+1] += c
        coeff = new
    den = prod((prefix[0]-a for a in prefix[1:]), start=1)
    return [x/den for x in coeff]

def evaluate(coeff, x):
    return sum((c*Q(x)**j for j,c in enumerate(coeff)), Q(0))

def local_checks():
    count = 0
    for nodes,k in [([0,1,2],3),([-2,0,3,7],4),([0,1,2,3,4],5)]:
        for a in product(nodes, repeat=k):
            m = k-1
            R = [Q(1)]
            polys = []
            for i in range(1,k):
                coeff = polynomial(a[:i]);polys.append(coeff)
                E = Q(a[i]==a[0])-evaluate(coeff,a[i])
                R.append(R[-1]*E)
                assert bool(R[-1]) == (len(set(a[:i+1])) == i+1)
            Delta = [prod((Q(a[j]==a[0]) for j in range(i,k)),start=Q(1)) for i in range(1,k+1)]
            terms = []
            for i in range(1,k):
                lhs = R[i-1]*Delta[i-1]-R[i]*Delta[i]
                rhs = R[i-1]*evaluate(polys[i-1],a[i])*Delta[i]
                assert lhs==rhs
                terms.append(rhs)
            assert sum(terms,Q(0))==detector(a)==Delta[0]-R[-1]
            count+=1
    return count

def weighted_tail_checks():
    count=0
    for m in range(2,7):
        for D in [m*(m+1)//2+1,4*m*m]:
            for i in range(1,m+1):
                for n in range(1,13):
                    # Equal rational proportions are sufficient for regression.
                    alpha=Q(1,m);t=Q(2)
                    start=(n+m-1)//m
                    tail=sum(comb(n,s)*i**s*(D-i)**(n-s) for s in range(start,n+1))
                    assert Q(tail**m)<=((D-i+i*t)**(n*m))/t**n
                    count+=1
    return count

def block_average_checks():
    cases=[]
    for N,D,s in [(5,3,2),(6,3,3),(6,4,2)]:
        t=min(s,(N-s)//(D-1));core_size=s-t
        family={frozenset(x) for x in combinations(range(N),s) if 0 in x}
        hits=0;total=0
        for p in permutations(range(N)):
            blocks=[p[i*D:(i+1)*D] for i in range(t)]
            core=p[D*t:D*t+core_size]
            model={frozenset(core+choice) for choice in product(*blocks)}
            assert len(model)==D**t
            hits+=len(model&family);total+=1
        expected=Q(len(family)*D**t,comb(N,s))
        assert Q(hits,total)==expected
        cases.append({'N':N,'D':D,'s':s,'t':t,'models_with_multiplicity':total,'intersection_mean':str(expected)})
    return cases

def rounding_checks():
    count=0
    for N in range(0,25):
        for D in range(3,9):
            for s in range(N+1):
                rho=Q(3,4);t=min(s,(N-s)//(D-1))
                # Raise both terms to D-1 to avoid fractional exponent.
                assert rho**(t*(D-1)) <= max(rho**(s*(D-1)),rho**(N-s-(D-1)))
                count+=1
    return count

if __name__=='__main__':
    report={'local_tuples':local_checks(),'weighted_tail_checks':weighted_tail_checks(),
            'block_average_cases':block_average_checks(),'rounding_checks':rounding_checks(),
            'arithmetic':'exact integers and fractions','passed':True}
    print(json.dumps(report,indent=2))
    Path(__file__).with_name('proof_chain_checks.json').write_text(json.dumps(report,indent=2))

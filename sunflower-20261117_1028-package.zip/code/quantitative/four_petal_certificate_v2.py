"""Exact rational/integer certificate; Python standard library only."""
from fractions import Fraction as Q
from pathlib import Path
import json,time
START=time.time();C=Q(95327,5000);rho=C/25;den=100000;AA=[24905,33903,41192]
assert sum(AA)==den
report=[]
for i,a in enumerate(AA,1):
 alpha=Q(a,den);t=alpha*(25-i)/(i*(1-alpha))
 L=((25-i+i*t)/C)**den;R=t**a
 left=L.numerator*R.denominator;right=R.numerator*L.denominator
 assert left<=right
 report.append({'i':i,'alpha':str(alpha),'weight':str(t),'integer_left_bits':left.bit_length(),'integer_right_bits':right.bit_length(),'passed':True})
assert rho<Q(247193,250000)**24
assert 1+1/rho==Q(220327,95327)<Q(289,125)
result={'C':str(C),'rho':str(rho),'alpha_denominator':den,'stage_certificates':report,'set_base':str(Q(497193,250000)),'prefactor':str(1+1/rho),'base_decimal':'1.988772','simple_prefactor_decimal':'2.312','passed':True,'elapsed_seconds':time.time()-START}
print(json.dumps(result,indent=2))
Path(__file__).with_name('four_petal_certificate_v2.json').write_text(json.dumps(result,indent=2))

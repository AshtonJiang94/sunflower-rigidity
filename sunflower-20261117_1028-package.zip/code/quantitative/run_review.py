"""Single entry point for independent peer-review verification.
Run without Python -O: the individual certificates deliberately use asserts.
"""
from pathlib import Path
import argparse,subprocess,sys,time,json,os,platform,hashlib
ROOT=Path(__file__).resolve().parent
EXACT=['four_petal_certificate_v2.py','verify_rigidity_v2.py','verify_proof_chain.py','verify_standalone_constants.py']
INTERVAL=['certify_gamma_v2.py','certify_four_optimum_v2.py']
EXPLORATORY=['detector_profile_search_v2.py']

def run(files):
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',PYTHONOPTIMIZE='0')
    records=[]
    for name in files:
        start=time.monotonic()
        proc=subprocess.run([sys.executable,str(ROOT/name)],cwd=ROOT,env=env,capture_output=True,text=True)
        log=ROOT/'logs'/f'{Path(name).stem}.log';log.parent.mkdir(exist_ok=True)
        log.write_text(proc.stdout+'\nSTDERR\n'+proc.stderr)
        print(name,'PASS' if proc.returncode==0 else 'FAIL',round(time.monotonic()-start,2),'seconds',flush=True)
        records.append({'script':name,'exit_code':proc.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log.relative_to(ROOT)),'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()})
        if proc.returncode:raise RuntimeError(f'{name} failed; see {log}')
    return records

if __name__=='__main__':
    if not __debug__:raise RuntimeError('Do not run certificates with Python -O')
    ap=argparse.ArgumentParser();ap.add_argument('--mode',choices=['exact','interval','exploratory','all'],default='all');args=ap.parse_args()
    files={'exact':EXACT,'interval':INTERVAL,'exploratory':EXPLORATORY,'all':EXACT+INTERVAL+EXPLORATORY}[args.mode]
    records=run(files)
    result={'mode':args.mode,'python':sys.version,'platform':platform.platform(),'scripts':records,'passed':True}
    (ROOT/'run_results.json').write_text(json.dumps(result,indent=2))

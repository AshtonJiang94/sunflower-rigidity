from pathlib import Path
from itertools import product,permutations
import numpy as np,json
import sys
sys.path.insert(0,str(Path(__file__).parent/'prior'))
from detector_profile_search_v2 import run

def mul(a,b):
 r=0
 while b:
  if b&1:r^=a
  b>>=1;a<<=1
  if a&4:a^=7
 return r
MT=np.array([[mul(i,j) for j in range(4)] for i in range(4)],dtype=np.int64)
INV={a:next(b for b in range(1,4) if mul(a,b)==1) for a in range(1,4)}

def interp4():
 A=np.zeros((4,4),dtype=np.int64)
 for x in range(4):
  c=[1];den=1
  for y in range(4):
   if y==x:continue
   cc=[0]*(len(c)+1)
   for j,z in enumerate(c):cc[j]^=mul(y,z);cc[j+1]^=z
   c=cc;den=mul(den,x^y)
  A[:,x]=[mul(z,INV[den]) for z in c]
 return A

def gf4(ds):
 k=len(ds);rain=np.array(list(permutations(range(4),k)),dtype=np.int64);A=interp4();rows=[]
 for es in product(*[range(d,4) for d in ds]):
  rr=np.ones(len(rain),dtype=np.int64);diag=np.ones(4,dtype=np.int64)
  for i,e in enumerate(es):rr=MT[rr,A[e,rain[:,i]]];diag=MT[diag,A[e]]
  rows.append(np.r_[rr,np.bitwise_xor.reduce(diag)])
 M=np.array(rows);original=M.copy();rank=0;pivs=[]
 for col in range(len(rain)):
  ix=np.flatnonzero(M[rank:,col])
  if not len(ix):continue
  j=rank+int(ix[0]);M[[rank,j]]=M[[j,rank]];M[rank]=MT[M[rank],INV[int(M[rank,col])]]
  ids=np.flatnonzero(M[:,col]);ids=ids[ids!=rank];M[ids]^=MT[M[ids,col,None],M[rank,None,:]]
  pivs.append(col);rank+=1
  if rank==len(M):break
 bad=bool(np.any((M[:,:-1]==0).all(axis=1)&(M[:,-1]!=0)))
 solution=None
 if not bad:
  free=[c for c in range(len(rain)) if c not in pivs]
  z=np.zeros(len(rain),dtype=np.int64);best=None;minimum_zeros=len(rain)+1
  for assignment in product(range(4),repeat=len(free)):
   candidate=np.zeros(len(rain),dtype=np.int64);candidate[free]=assignment
   for r,c in enumerate(pivs):candidate[c]=M[r,-1]^np.bitwise_xor.reduce(MT[M[r,free],candidate[free]],initial=0)
   zeros=int(np.count_nonzero(candidate==0))
   if zeros<minimum_zeros:minimum_zeros=zeros;best=candidate.copy()
   if zeros==0:break
  z=best
  residual=np.bitwise_xor.reduce(MT[original[:,:-1],z[None,:]],axis=1)^original[:,-1];assert not np.any(residual)
  solution=[{'tuple':a.tolist(),'value':int(v)} for a,v in zip(rain,z)]
 return dict(field='GF(4)',representation='GF(2)[z]/(z^2+z+1), elements 0,1,z,z+1 encoded 0,1,2,3',ds=ds,rank=rank,consistent=not bad,dimension=len(rain)-rank if not bad else None,minimum_zero_rainbow_values=minimum_zeros if not bad else None,solution=solution)
if __name__=='__main__':
 out=[]
 for ds in [(0,1,2,2),(0,1,2,3),(1,1,1,1),(1,1,1,2),(1,1,2,2),(1,1,1,3)]:
  r=gf4(ds);out.append(r);print({k:v for k,v in r.items() if k!='solution'},flush=True)
 for q in [5,7]:
  for ds in [(0,1,2,2),(1,1,1,1),(1,1,1,2),(1,1,2,2),(1,1,1,3)]:
   r=run(q,ds,P=q);out.append(r);print(r,flush=True)
 Path(__file__).with_name('finite_characteristic_results.json').write_text(json.dumps(out,indent=2))

"""Exact regression certificates, not substitutes for the general proofs."""
from pathlib import Path
from itertools import permutations,product,combinations,combinations_with_replacement
from fractions import Fraction as F
from math import prod,factorial
import numpy as np,json,sys,random
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT));from explore_profiles import fixed
from finite_characteristic import MT,INV,interp4,gf4

def rr(M,p):
 M=np.array(M,dtype=np.int64).copy();rank=0;pivs=[]
 for c in range(M.shape[1]):
  ids=np.flatnonzero(M[rank:,c])
  if not len(ids):continue
  j=rank+int(ids[0]);M[[rank,j]]=M[[j,rank]];M[rank]=M[rank]*pow(int(M[rank,c]),-1,p)%p
  ids=np.flatnonzero(M[:,c]);ids=ids[ids!=rank];M[ids]=(M[ids]-M[ids,c,None]*M[rank,None,:])%p;pivs.append(c);rank+=1
  if rank==len(M):break
 return M,pivs

def mds_random(D,d,p,rng):
 while True:
  G=np.array([[rng.randrange(p) for _ in range(D)] for _ in range(d)],dtype=np.int64)
  if all(len(rr(G[:,cols],p)[1])==d for cols in combinations(range(D),d)):return G

def dual(G,p):
 R,pivs=rr(G,p);D=G.shape[1];free=[c for c in range(D) if c not in pivs];W=[]
 for f in free:
  row=np.zeros(D,dtype=np.int64);row[f]=1
  for i,c in enumerate(pivs):row[c]=-R[i,f]%p
  W.append(row)
 W=np.array(W);assert not np.any(G@W.T%p);return W

def mds_case(D,ds,p,anchor,rng):
 G=[mds_random(D,d,p,rng) for d in ds];W=[dual(g,p) for g in G];rain=np.array(list(permutations([x for x in range(D) if x!=anchor],len(ds))));rows=[]
 for es in product(*[range(len(a)) for a in W]):
  row=np.ones(len(rain),dtype=np.int64);b=1
  for i,e in enumerate(es):row=row*W[i][e,rain[:,i]]%p;b=b*int(W[i][e,anchor])%p
  rows.append(np.r_[row,-b%p])
 M=np.array(rows);R,pivs=rr(M[:,:-1],p);rank=len(pivs);assert rank==prod(D-d for d in ds)
 # Solve the system directly with augmented RREF, and check original residual.
 aug=M.copy();rank2=0;pcols=[]
 for c in range(len(rain)):
  ids=np.flatnonzero(aug[rank2:,c])
  if not len(ids):continue
  j=rank2+int(ids[0]);aug[[rank2,j]]=aug[[j,rank2]];aug[rank2]=aug[rank2]*pow(int(aug[rank2,c]),-1,p)%p
  ids=np.flatnonzero(aug[:,c]);ids=ids[ids!=rank2];aug[ids]=(aug[ids]-aug[ids,c,None]*aug[rank2,None,:])%p;pcols.append(c);rank2+=1
  if rank2==len(aug):break
 z=np.zeros(len(rain),dtype=np.int64)
 for i,c in enumerate(pcols):z[c]=aug[i,-1]
 assert not np.any((M[:,:-1]@z-M[:,-1])%p)
 if tuple(ds)==tuple(range(1,len(ds)+1)):assert np.all(z!=0)
 return dict(D=D,ds=ds,p=p,anchor=anchor,generators=[g.tolist() for g in G],duals=[v.tolist() for v in W],rank=rank,affine_dimension_per_anchor=len(rain)-rank,solution=z.tolist(),rainbow_tuples=rain.tolist(),residual_zero=True)

def qrank(M):
 M=[[F(x) for x in row] for row in M];n=len(M);k=len(M[0]);r=0
 for c in range(k):
  j=next((i for i in range(r,n) if M[i][c]),None)
  if j is None:continue
  M[r],M[j]=M[j],M[r];v=M[r][c];M[r]=[x/v for x in M[r]]
  for i in range(r+1,n):
   v=M[i][c]
   if v:M[i]=[x-v*y for x,y in zip(M[i],M[r])]
  r+=1
  if r==n:break
 return r

def qcase(nodes,ds,anchor):
 weights={x:1/prod((F(x-y) for y in nodes if y!=x),start=F(1)) for x in nodes};rain=list(permutations([x for x in nodes if x!=anchor],len(ds)));rows=[]
 for es in product(*[range(len(nodes)-d) for d in ds]):rows.append([prod((weights[x]*F(x)**e for x,e in zip(a,es)),start=F(1)) for a in rain])
 rank=qrank(rows);assert rank==prod(len(nodes)-d for d in ds)
 return dict(field='Q',nodes=nodes,ds=ds,anchor=anchor,rank=rank,dimension_per_anchor=len(rain)-rank)

anchored=[]
for p in [1009,1013]:
 for D in [5,6,7,8]:
  for ds in [(1,2,3),(2,2,3),(2,3,3),(3,3,3),(1,3,3),(1,2,4),(2,2,4)]:
   for anchor in [0,D-1]:
    a=fixed(D,ds,p,anchor);expected=factorial(D-1)//factorial(D-4)-prod(D-d for d in ds)
    assert a['consistent'] and a['dimension']==expected;anchored.append(a)
# Enumerate all feasible sorted 3-direction profiles for D=5.
for ds in combinations_with_replacement(range(1,5),3):
 if not all(d>=i for i,d in enumerate(ds,1)):continue
 a=fixed(5,ds);assert a['dimension']==24-prod(5-d for d in ds);anchored.append(a)
qs=[qcase(nodes,ds,nodes[0]) for nodes,ds in [([0,1,2,3],(1,2,3)),([0,1,2,3],(2,2,3)),([-3,0,2,7,11],(1,2,3)),([-3,0,2,7,11],(2,3,3)),([0,1,2,3,4],(3,3,3))]]
rng=random.Random(612003);mds=[]
for D,ds in [(4,(1,2,3)),(5,(1,2,3)),(5,(2,2,3)),(5,(2,3,3)),(6,(2,2,4))]:
 for anchor in [0,D-1]:mds.append(mds_case(D,ds,1009,anchor,rng))
# Ordered-field obstruction: every diagonal term on nested grids has one sign.
ordered=[]
for k,D in [(4,5),(6,7)]:
 for ds in combinations_with_replacement(range(k),k):
  if all(d>=i for i,d in enumerate(ds)):continue
  T=[list(range(d+1)) for d in ds]
  # Hall deficiency implies no all-distinct tuple; certify using prefix size.
  j=next(i for i,d in enumerate(ds) if d<i);assert len(set().union(*[set(x) for x in T[:j+1]]))<j+1
  weights=[{x:1/prod((F(x-y) for y in t if y!=x),start=F(1)) for x in t} for t in T]
  vals=[prod((ww[x] for ww in weights),start=F(1)) for x in T[0]]
  assert all(v>0 for v in vals) or all(v<0 for v in vals);assert sum(vals)!=0
  ordered.append(dict(k=k,D=D,ds=ds,diagonal_contraction=str(sum(vals))))
# Explicit non-MDS counterexample to a componentwise dual-distance condition.
# A={0,1,2,3}; U1 point-indicator(0), U2 point-indicators(1,2,3).
for a,x,y in product(range(4),repeat=3):
 Q=int(a==x==y)
 decomp=int(a==0)*int(x==0)*int(y==0)+sum(int(a==b)*int(x==b)*int(y==b) for b in [1,2,3])
 assert Q==decomp
# Both dual spaces have a support-one vector, so both minimum dual distances are 1.
nonmds=dict(D=4,m=2,dimensions=[1,3],dual_minimum_distances=[1,1],definition='normalized detector, rainbow values may be zero',rainbow_nonzero=False,all_64_values_checked=True)
# Independent reconstruction of the short GF(4) difference-ratio example.
A=interp4();points=list(product(range(4),repeat=4));V=[]
for a in points:
 val=1 if len(set(a))==1 else int(MT[a[0]^a[1],INV[a[0]^a[2]]]) if len(set(a))==4 else 0;V.append(val)
 if len(set(a))==4:
  original=1
  for s in range(1,3):
   for j in range(s+1,4):original=int(MT[original,a[j]^a[s]])
  den=int(MT[MT[a[0]^a[1],a[0]^a[1]],a[0]^a[2]])
  assert val==int(MT[original,INV[den]])
C=[]
for es in points:
 coeff=0
 for a,v in zip(points,V):
  term=v
  for i,e in enumerate(es):term=int(MT[term,A[e,a[i]]])
  coeff^=term
 if coeff:
  assert any(es[i]<[1,1,1,3][i] for i in range(4));C.append(dict(exponents=es,coefficient=coeff))
for a,v in zip(points,V):
 total=0
 for term in C:
  c=term['coefficient']
  for x,e in zip(a,term['exponents']):
   xp=1
   for _ in range(e):xp=int(MT[xp,x])
   c=int(MT[c,xp])
  total^=c
 assert total==v
assert len(C)==37
S=set()
for pattern in [(0,0,0,3),(0,1,1,1),(0,0,3,3),(1,1,2,2),(0,2,2,2)]:S.update(permutations(pattern))
for e in permutations((0,1,2,3)):
 if sum(e[i]>e[j] for i in range(4) for j in range(i+1,4))%2:S.add(e)
assert set(tuple(c['exponents']) for c in C)==S|{(0,0,0,0)}
assert all(c['coefficient']==1 for c in C)
witness=sorted(set(permutations((0,0,3,3)))|set(permutations((1,1,2,2))))
assert len(witness)==12
assert set(witness)<=set(tuple(c['exponents']) for c in C)
for i in range(4):assert [sum(a[i]==j for a in witness) for j in range(4)]==[3,3,3,3]
(ROOT/'gf4_support_witness.json').write_text(json.dumps({'support':witness,'weight_each':'1/12','marginal_each_letter':'1/4','consequence':'Fixed monomial cylinder-cover exponent is 4, by the type-class lower bound.'},indent=2))
(ROOT/'gf4_ratio_certificate.json').write_text(json.dumps(dict(field='GF(4)',dimensions=[1,1,1,3],ratio='(a0+a1)/(a0+a2)',terms=C,points_checked=256,rainbows_checked=24,equals_original_detector=True),indent=2))
out=dict(anchored_modular_tests=anchored,rational_tests=qs,independent_mds_tests=mds,ordered_obstruction_checks=ordered,nonmds_counterexample=nonmds,gf4_verified=True,gf4_nonzero_terms=37,all_passed=True,interpretation='Finite exact regression only; general theorems rely on written proofs.')
(ROOT/'new_structure_checks.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'anchored_tests':len(anchored),'rational_tests':len(qs),'independent_mds_tests':len(mds),'ordered_profiles':len(ordered),'gf4_points':256,'passed':True},indent=2))

from pathlib import Path
from itertools import product,permutations,combinations_with_replacement
import numpy as np,json,time,sys
BASE=Path(__file__).parent
sys.path.insert(0,str(BASE/'prior'))
from detector_profile_search_v2 import interp,eliminate,run

def fixed(D,ds,p=1009,anchor=0):
 A=interp(D,p);rain=np.array(list(permutations([x for x in range(D) if x!=anchor],len(ds))),dtype=np.int64)
 rows=[]
 for es in product(*[range(d,D) for d in ds]):
  rr=np.ones(len(rain),dtype=np.int64);diag=1
  for i,e in enumerate(es):rr=rr*A[e,rain[:,i]]%p;diag=diag*int(A[e,anchor])%p
  rows.append(np.r_[rr,-diag%p])
 M=np.array(rows,dtype=np.int64);rank,bad=eliminate(M,p)
 return dict(kind='anchored',D=D,ds=ds,p=p,anchor=anchor,nvars=len(rain),nrows=len(rows),rank=rank,consistent=not bad,dimension=None if bad else len(rain)-rank)

if __name__=='__main__':
 out=[]
 for D in [4,5,6,7]:
  for ds in [(1,2,3),(2,2,3),(2,3,3),(3,3,3),(1,3,3),(1,2,4),(2,2,4)]:
   if max(ds)>=D:continue
   r=fixed(D,ds);out.append(r);print(r,flush=True)
 for D in [4,5]:
  for ds in [(1,1,1,1),(1,1,1,2),(1,1,2,2),(1,1,1,3),(0,1,2,3),(1,1,2,3),(1,2,2,2)]:
   r=run(D,ds,P=1009);out.append(r);print(r,flush=True)
 (BASE/'initial_profile_search.json').write_text(json.dumps(out,indent=2))

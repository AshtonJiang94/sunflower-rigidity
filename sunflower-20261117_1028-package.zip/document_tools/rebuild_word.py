from pathlib import Path
from datetime import datetime,timezone,timedelta
import importlib.util,re,json,zipfile,hashlib,shutil
from lxml import etree
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
ROOT=Path(__file__).resolve().parent.parent;W=ROOT/'sources';OUT=ROOT/'rebuilt';OUT.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('builder',ROOT/'document_tools/tex_to_omml.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.OUT=OUT;b.STAMP=datetime.now(timezone(timedelta(hours=8))).strftime('%Y%m%d_%H%M');b.SYMS.update({'Omega':'Ω','oplus':'⊕'});b.BBOARD['F']='𝔽';b.CAL.update({'L':'ℒ','S':'𝒮','O':'𝒪'});b.OPERATORS['bigotimes']='⨂'

def display_rows(s):
 if '\\qquad' in s and len(s)>110:return s.split('\\qquad')
 return [s]
b.split_aligned=display_rows

def prepare(s):
 for locator in re.findall(r'\\cite\[([^\]]*)\]',s):
  if '\\ref' in locator or '\\eqref' in locator:
   raise ValueError('External citation locators must not use internal manuscript labels: '+locator)
 s=re.sub(r'\\begin\{gathered\}(.*?)\\end\{gathered\}',lambda m:m[1].replace('\\\\','\\qquad'),s,flags=re.S)
 refs={x:int(x.split(':')[1]) for x in re.findall(r'\\label\{([^}]+)\}',s)}
 bib=re.search(r'\\begin\{thebibliography\}\{[^}]+\}(.*?)\\end\{thebibliography\}',s,re.S)
 if bib is None:
  return s.replace('~',' ')
 entries=re.split(r'\\bibitem\{([^}]+)\}',bib[1]);keys=entries[1::2];vals=entries[2::2];bm={k:i+1 for i,k in enumerate(keys)}
 def cite(m):
  return '['+','.join(str(bm[k]) for k in m[2].split(','))+((', '+m[1]) if m[1] else '')+']'
 s=re.sub(r'\\cite(?:\[([^\]]*)\])?\{([^}]+)\}',cite,s)
 s=re.sub(r'\\ref\{([^}]+)\}',lambda m:str(refs[m[1]]),s);s=re.sub(r'\\label\{[^}]+\}','',s)
 s=re.sub(r'\\begin\{equation\}(.*?)\\end\{equation\}',lambda m:'\\[\n'+m[1].strip()+'\n\\]',s,flags=re.S)
 entries=[f'[{i+1}] '+v.strip() for i,v in enumerate(vals)]
 s=re.sub(r'\\begin\{thebibliography\}\{[^}]+\}.*?\\end\{thebibliography\}',lambda m:'\\section*{'+('参考文献' if 'ctexart' in s else 'References')+'}\n\n'+'\n\n'.join(entries),s,flags=re.S)
 s=s.replace('~',' ')
 return s

specs=[('original_cn','无葵花族_原命题完整证明重构_CN','zh'),('original_en','Sunflower_Original_Proof_Reconstruction_EN','en'),('optimization_cn','葵花检测器_结构与优化整合论文_CN','zh'),('optimization_en','Sunflower_Integrated_Structure_and_Optimization_EN','en')]
specs += [('contributions_cn','葵花论文_重构与主要贡献说明_CN','zh'),('contributions_en','Sunflower_Principal_Contributions_and_Scope_EN','en')]
reports=[];paths=[]
for name,base,lang in specs:
 src=W/(name+'.tex');prep=W/(name+'_word.tex');prep.write_text(prepare(src.read_text()))
 inf=b.build(prep,base,lang,tex_output=False)
 d=Document(inf['docx']);d.paragraphs[1].text='姜志成' if lang=='zh' else 'JIANG ZHICHENG';d.paragraphs[1].alignment=WD_ALIGN_PARAGRAPH.CENTER;d.paragraphs[1].paragraph_format.space_after=Pt(12);d.paragraphs[0].alignment=WD_ALIGN_PARAGRAPH.CENTER
 d.core_properties.author='姜志成 (JIANG ZHICHENG)';d.core_properties.subject='Mathematical manuscript; proof reconstruction' if name.startswith('original') else 'Mathematical manuscript; integrated structural and quantitative analysis';d.core_properties.comments='Native editable OMML equations; substantial AI assistance disclosed in the text.'
 d.save(inf['docx']);tex=OUT/(base+'_'+b.STAMP+'.tex');shutil.copy2(src,tex);inf['tex']=str(tex)
 with zipfile.ZipFile(inf['docx']) as z:
  assert z.testzip() is None
  for n in z.namelist():
   if n.endswith('.xml'):etree.fromstring(z.read(n))
  rt=etree.fromstring(z.read('word/document.xml'));ns={'w':b.W,'m':b.M};text=''.join(rt.xpath('//w:t/text()|//m:t/text()',namespaces=ns));assert not re.search(r'\\[A-Za-z]+',text)
  assert 'JIANG ZHICHENG' in ''.join(etree.fromstring(z.read('docProps/core.xml')).itertext())
  assert len(rt.xpath('//m:oMath',namespaces=ns))==inf['native_math_objects']
 paths.extend([inf['docx'],str(tex)]);reports.append(inf)
(W/'build_report.json').write_text(json.dumps({'stamp':b.STAMP,'documents':reports,'files':paths},ensure_ascii=False,indent=2));print(json.dumps({'stamp':b.STAMP,'documents':reports,'files':paths},ensure_ascii=False,indent=2))

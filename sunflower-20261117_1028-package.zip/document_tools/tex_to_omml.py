"""Deterministic TeX subset -> native OMML and Word for these manuscripts.
No numerical theorem is established by this document builder. Unsupported
formula commands cause a hard failure. Source files and numbering are checked.
"""
from pathlib import Path
from datetime import datetime,timezone,timedelta
from copy import deepcopy
import re,json,zipfile
from lxml import etree
from docx import Document
from docx.shared import Pt,Mm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
ROOT=Path(__file__).resolve().parent.parent;CV=ROOT/'converted';OUT=ROOT/'outputs'
STAMP=datetime.now(timezone(timedelta(hours=8))).strftime('%Y%m%d_%H%M')
M='http://schemas.openxmlformats.org/officeDocument/2006/math'
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'
SYMS={'Delta':'Δ','Lambda':'Λ','alpha':'α','beta':'β','gamma':'γ','delta':'δ','lambda':'λ','rho':'ρ','varepsilon':'ε','ell':'ℓ','leq':'≤','geq':'≥','ne':'≠','approx':'≈','sim':'∼','in':'∈','subset':'⊂','subseteq':'⊆','infty':'∞','otimes':'⊗','cdot':'⋅','times':'×','cup':'∪','setminus':'∖','perp':'⊥','partial':'∂','ldots':'…','cdots':'⋯','to':'→','longrightarrow':'⟶','mapsto':'↦','langle':'⟨','rangle':'⟩','lfloor':'⌊','rfloor':'⌋','qquad':'  ','quad':' ','log':'log','exp':'exp','dim':'dim','min':'min','max':'max','sup':'sup','lim':'lim','liminf':'lim inf'}
OPERATORS={'sum':'∑','prod':'∏','int':'∫','bigcup':'⋃'}
PLAIN={'log','exp','dim','min','max','sup','lim','liminf'}
BBOARD={'A':'𝔸','D':'𝔻','E':'𝔼','K':'𝕂','N':'ℕ','P':'ℙ','Q':'ℚ','R':'ℝ','X':'𝕏','Z':'ℤ'}
CAL={'F':'ℱ','T':'𝒯','P':'𝒫','G':'𝒢','A':'𝒜'}

def node(tag,children=(),attrs=None):
    x=etree.Element('{'+M+'}'+tag)
    if attrs:
        for k,v in attrs.items():x.set('{'+M+'}'+k,str(v))
    for c in children:x.append(c)
    return x

def mr(text,plain=False):
    el=node('r')
    if plain:el.append(node('rPr',[node('sty',attrs={'val':'p'})]))
    t=node('t');t.text=text;t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');el.append(t)
    return el

def wrap(tag,seq):return node(tag,seq)

class Parser:
    def __init__(self,s):self.s=s;self.i=0;self.commands=[]
    def space(self):
        while self.i<len(self.s) and self.s[self.i].isspace():self.i+=1
    def rawgroup(self):
        self.space();assert self.i<len(self.s) and self.s[self.i]=='{',self.s[self.i:]
        self.i+=1;start=self.i;depth=1
        while self.i<len(self.s):
            ch=self.s[self.i];self.i+=1
            if ch=='{':depth+=1
            if ch=='}':depth-=1
            if depth==0:return self.s[start:self.i-1]
        raise ValueError('unclosed group')
    def argument(self):
        self.space()
        if self.i<len(self.s) and self.s[self.i]=='{':
            raw=self.rawgroup();pp=Parser(raw);seq=pp.sequence();self.commands+=pp.commands;return seq
        el,_,_=self.atom();return [el] if el is not None else []
    def atom(self):
        self.space()
        if self.i>=len(self.s):return None,None,None
        ch=self.s[self.i];self.i+=1
        if ch=='{':
            self.i-=1;return node('box',[wrap('e',self.argument())]),None,None
        if ch!='\\':return mr(ch,plain=ch.isdigit()),None,None
        if self.i>=len(self.s):raise ValueError('trailing slash')
        if not self.s[self.i].isalpha():
            c=self.s[self.i];self.i+=1
            if c in ',;! ':return mr(' ' if c!='!' else '',True),None,None
            if c in '{}_%&#':return mr(c,True),None,None
            raise ValueError('unsupported escape '+c)
        mat=re.match(r'[A-Za-z]+',self.s[self.i:]);cmd=mat.group();self.i+=len(cmd);self.commands.append(cmd)
        if cmd in ['left','right']:return self.atom()
        if cmd in SYMS:return mr(SYMS[cmd],cmd in PLAIN),('limit' if cmd in ['lim','liminf','sup','min','max'] else None),None
        if cmd in OPERATORS:return mr(OPERATORS[cmd]),'nary',OPERATORS[cmd]
        if cmd in ['frac','binom']:
            num=self.argument();den=self.argument()
            pr=node('fPr',[node('type',attrs={'val':'noBar' if cmd=='binom' else 'bar'})])
            f=node('f',[pr,wrap('num',num),wrap('den',den)])
            if cmd=='binom':f=node('d',[node('dPr',[node('begChr',attrs={'val':'('}),node('endChr',attrs={'val':')'})]),wrap('e',[f])])
            return f,None,None
        if cmd=='widehat':return node('acc',[node('accPr',[node('chr',attrs={'val':'̂'})]),wrap('e',self.argument())]),None,None
        if cmd in ['text','operatorname','mathrm','mathbb','mathcal']:
            self.space()
            if self.i<len(self.s) and self.s[self.i]=='{':raw=self.rawgroup()
            elif cmd in ['mathrm','mathbb','mathcal']:
                raw=self.s[self.i];self.i+=1
            else:raise ValueError('text command requires group')
            if cmd=='mathbb':raw=''.join(BBOARD.get(c,c) for c in raw)
            if cmd=='mathcal':raw=''.join(CAL.get(c,c) for c in raw)
            assert '\\' not in raw,('nested text command',raw)
            return mr(raw,True),None,None
        raise ValueError('unsupported command '+cmd)
    def sequence(self):
        out=[]
        while True:
            self.space()
            if self.i>=len(self.s):break
            if self.s[self.i]=='}':raise ValueError('unmatched brace')
            base,kind,glyph=self.atom()
            if base is None:break
            sub=None;sup=None
            while True:
                self.space()
                if self.i<len(self.s) and self.s[self.i] in '_^':
                    mark=self.s[self.i];self.i+=1;v=self.argument()
                    if mark=='_':
                        if sub is not None:raise ValueError('duplicate subscript')
                        sub=v
                    else:
                        if sup is not None:raise ValueError('duplicate superscript')
                        sup=v
                else:break
            if kind=='nary':
                # The expression field may extend through a following equality;
                # this changes grouping only, not the displayed mathematical text.
                rest=self.sequence()
                pr=node('naryPr',[node('chr',attrs={'val':glyph}),node('limLoc',attrs={'val':'undOvr'}),node('grow',attrs={'val':'1'}),node('subHide',attrs={'val':'0' if sub is not None else '1'}),node('supHide',attrs={'val':'0' if sup is not None else '1'})])
                out.append(node('nary',[pr,wrap('sub',sub or []),wrap('sup',sup or []),wrap('e',rest or [mr(' ')])]))
                break
            if kind=='limit' and sub is not None:
                base=node('limLow',[wrap('e',[base]),wrap('lim',sub)]);sub=None
            if sub is not None and sup is not None:base=node('sSubSup',[wrap('e',[base]),wrap('sub',sub),wrap('sup',sup)])
            elif sub is not None:base=node('sSub',[wrap('e',[base]),wrap('sub',sub)])
            elif sup is not None:base=node('sSup',[wrap('e',[base]),wrap('sup',sup)])
            out.append(base)
        return out

def math(s):
    pp=Parser(s);parts=pp.sequence();assert pp.i==len(s)
    return node('oMath',parts),pp.commands

def split_aligned(s):
    # Split long joined displays into separate native equation-array rows.
    if len(s)>170 and '\\qquad' in s:return s.split('\\qquad')
    if len(s)>220 and '\n=' in s:return s.split('\n=')[0:1]+['='+x for x in s.split('\n=')[1:]]
    return [s]

def add_math(p,s,display=False):
    commands=[]
    rows=split_aligned(s) if display else [s]
    if len(rows)==1:om,commands=math(s)
    else:
        elements=[]
        for row in rows:
            om,c=math(row);elements.append(wrap('e',list(om)));commands+=c
        om=node('oMath',[node('eqArr',elements)])
    p._p.append(om);return commands

def untex(t):
    t=t.replace('\\noindent','').replace('\\par',' ')
    for cmd in ['texttt','textbf','emph','url']:
        t=re.sub(r'\\'+cmd+r'\{([^{}]*)\}',lambda m:m.group(1),t)
    t=t.replace('\\_','_').replace('--','–')
    return t

def add_text(p,s):
    cmds=[]
    chunks=re.split(r'(\$[^$]*\$)',s,flags=re.S)
    for ch in chunks:
        if ch.startswith('$') and ch.endswith('$'):cmds+=add_math(p,ch[1:-1])
        elif ch:
            # Preserve monospace filename runs and emphasis.
            patterns=r'(\\(?:texttt|textbf|emph)\{[^{}]*\}|\\url\{[^{}]*\})'
            for part in re.split(patterns,ch):
                if not part:continue
                mm=re.fullmatch(r'\\(texttt|textbf|emph|url)\{([^{}]*)\}',part)
                text=untex(mm.group(2) if mm else part)
                text=re.sub(r'\s+',' ',text)
                run=p.add_run(text)
                if mm:
                    if mm.group(1)=='textbf':run.bold=True
                    if mm.group(1)=='emph':run.italic=True
                    if mm.group(1)=='texttt':run.font.name='Courier New';run.font.size=Pt(10)
    return cmds

def style(D,lang):
    for sec in D.sections:
        sec.page_width=Mm(210);sec.page_height=Mm(297)
        sec.left_margin=Mm(25);sec.right_margin=Mm(25);sec.top_margin=Mm(23);sec.bottom_margin=Mm(23)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3']:
        st=D.styles[name];st.font.name='Times New Roman';st.font.size=Pt(12);st.font.color.rgb=RGBColor(0,0,0)
        pr=st._element.get_or_add_rPr();fonts=pr.rFonts
        if fonts is None:fonts=OxmlElement('w:rFonts');pr.insert(0,fonts)
        fonts.set(qn('w:eastAsia'),'宋体')
        st.paragraph_format.line_spacing=1.3 if lang=='en' else 1.5
        st.paragraph_format.space_after=Pt(5)
    D.styles['Normal'].paragraph_format.first_line_indent=Pt(14 if lang=='en' else 24)
    for name,size in [('Title',17),('Heading 1',14),('Heading 2',12),('Heading 3',12)]:
        st=D.styles[name];st.font.size=Pt(size);st.font.bold=True
        st.paragraph_format.first_line_indent=Pt(0);st.paragraph_format.keep_with_next=True
        st.paragraph_format.space_before=Pt(10)
    D.styles['Subtitle'].paragraph_format.first_line_indent=Pt(0)
    D.styles['Subtitle'].font.size=Pt(11)
    # Set the default mathematics font without changing Latin body fonts.
    mathpr=D.settings.element.find(qn('m:mathPr'))
    if mathpr is None:mathpr=OxmlElement('m:mathPr');D.settings.element.append(mathpr)
    font=mathpr.find(qn('m:mathFont'))
    if font is None:font=OxmlElement('m:mathFont');mathpr.insert(0,font)
    font.set(qn('m:val'),'Cambria Math')


def build(source,basename,lang='en',tex_output=True):
    src=source.read_text();title=re.search(r'\\title\{([^}]*)\}',src).group(1)
    D=Document();style(D,lang)
    D.add_paragraph(title,style='Title')
    D.add_paragraph('Peer-review manuscript' if lang=='en' else '自包含完整证明稿',style='Subtitle')
    body=src.split('\\maketitle',1)[1].split('\\end{document}',1)[0]
    tokens=re.split(r'(\\\[.*?\\\]|\\section\*?\{[^}]*\}|\\subsection\{[^}]*\}|\\appendix|\\begin\{(?:abstract|theorem|lemma|proposition|proof)\}(?:\[[^\]]*\])?|\\end\{(?:abstract|theorem|lemma|proposition|proof)\})',body,flags=re.S)
    num=0;eq=0;sec=0;subsec=0;append=False;commands=[];statement_kinds=[];eqsources=[]
    names={'theorem':'Theorem','lemma':'Lemma','proposition':'Proposition'} if lang=='en' else {'theorem':'定理','lemma':'引理','proposition':'命题'}
    for tok in tokens:
        if not tok or not tok.strip():continue
        if tok=='\\appendix':append=True;sec=0;subsec=0;continue
        if tok.startswith('\\section') or tok.startswith('\\subsection'):
            mo=re.fullmatch(r'\\(section\*?|subsection)\{(.*)\}',tok,re.S);kind,txt=mo.groups()
            if kind=='subsection':subsec+=1;pref=(chr(64+sec) if append else str(sec))+'.'+str(subsec)+' '
            elif kind=='section*':pref=''
            else:sec+=1;subsec=0;pref=('Appendix ' if lang=='en' else '附录 ') +chr(64+sec)+' ' if append else str(sec)+' '
            D.add_paragraph(pref+untex(txt),style='Heading 2' if kind=='subsection' else 'Heading 1');continue
        if tok.startswith('\\begin{abstract}'):
            D.add_paragraph('Abstract' if lang=='en' else '摘要',style='Heading 1');continue
        mo=re.match(r'\\begin\{(theorem|lemma|proposition|proof)\}(?:\[(.*?)\])?',tok,re.S)
        if mo:
            kind,label=mo.groups();p=D.add_paragraph();p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.keep_with_next=True;p.paragraph_format.space_before=Pt(7)
            if kind=='proof':txt=(label or ('Proof' if lang=='en' else '证明'))
            else:num+=1;statement_kinds.append(kind);txt=names[kind]+' '+str(num)+'.'
            rr=p.add_run(txt);rr.bold=True;continue
        if tok.startswith('\\end{'):
            if tok=='\\end{proof}':
                p=D.add_paragraph('□');p.alignment=WD_ALIGN_PARAGRAPH.RIGHT;p.paragraph_format.space_after=Pt(1)
            continue
        if tok.startswith('\\['):
            eq+=1;s=tok[2:-2].strip();eqsources.append(s)
            p=D.add_paragraph();p.paragraph_format.first_line_indent=Pt(0);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before=Pt(5);p.paragraph_format.space_after=Pt(5);p.paragraph_format.keep_together=True
            commands+=add_math(p,s,display=True);r=p.add_run('   ('+str(eq)+')');r.font.size=Pt(10.5)
            continue
        for para in re.split(r'\n\s*\n',tok):
            if para.strip():commands+=add_text(D.add_paragraph(),para.strip())
    D.core_properties.title=title;D.core_properties.author='';D.core_properties.subject='Technical peer review; no public submission'
    for section in D.sections:
        p=section.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.first_line_indent=Pt(0)
        field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');p._p.append(field)
    path=OUT/(basename+'_'+STAMP+'.docx');D.save(path)
    texpath=None
    if tex_output:
        eqno=0;resno=0
        def ne(m):
            nonlocal eqno
            eqno+=1;return '\\begin{equation}\\label{eq:'+str(eqno)+'}\n'+m.group(1).strip()+'\n\\end{equation}'
        numbered=re.sub(r'\\\[(.*?)\\\]',ne,src,flags=re.S)
        def nr(m):
            nonlocal resno
            resno+=1;return m.group()+'\\label{result:'+str(resno)+'}'
        numbered=re.sub(r'\\begin\{(?:theorem|lemma|proposition)\}',nr,numbered)
        texpath=OUT/(basename+'_'+STAMP+'.tex');texpath.write_text(numbered)
        assert eqno==eq and resno==num
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        for name in z.namelist():
            if name.endswith('.xml'):etree.fromstring(z.read(name))
        rt=etree.fromstring(z.read('word/document.xml'))
    ns={'w':W,'m':M}
    txt=''.join(rt.xpath('//w:t/text()|//m:t/text()',namespaces=ns))
    assert not re.search(r'\\[A-Za-z]+',txt),re.findall(r'\\[A-Za-z]+',txt)
    if lang=='en':assert not re.search(r'[\u4e00-\u9fff]',txt)
    actual=[]
    for p in rt.xpath('//w:body/w:p',namespaces=ns):
        if p.find('m:oMath',ns) is not None:
            tail=''.join(p.xpath('./w:r/w:t/text()',namespaces=ns));mm=re.search(r'\((\d+)\)$',tail)
            if mm:actual.append(int(mm.group(1)))
    assert actual==list(range(1,eq+1))
    return {'docx':str(path),'tex':str(texpath) if texpath else None,'results':num,'result_kinds':statement_kinds,'display_equations':eq,'native_math_objects':len(rt.xpath('//m:oMath',namespaces=ns)),'formula_commands':sorted(set(commands)),'source':str(source)}

if __name__=='__main__':
    specs=[('research_en.tex','Sunflower_Rigidity_Full_Paper_EN','en',True),('improvements_en.tex','Sunflower_Principal_Contributions_EN','en',False),('standalone_zh.tex','无葵花族_原问题完整证明_CN','zh',True),('standalone_en.tex','Sunflower_Original_Problem_Complete_Proof_EN','en',True)]
    result=[build(CV/a,b,c,d) for a,b,c,d in specs]
    (CV/'bilingual_build_results.json').write_text(json.dumps({'stamp':STAMP,'documents':result},ensure_ascii=False,indent=2))
    print(json.dumps({'stamp':STAMP,'documents':result},ensure_ascii=False,indent=2))
